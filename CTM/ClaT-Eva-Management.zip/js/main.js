$(document).ready(function() {
	 $('[data-toggle="popover"]').popover();   
		startAniBG();
		// loadingShow();
		// endAniBG();
		// loadingHide();
	
});
